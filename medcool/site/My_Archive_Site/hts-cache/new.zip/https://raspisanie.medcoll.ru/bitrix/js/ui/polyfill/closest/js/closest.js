<!DOCTYPE html>
<html xml:lang="ru" lang="ru">
<head>
	<title>Карта сайта</title>
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta name="viewport" content="user-scalable=no, initial-scale=1.0, maximum-scale=1.0, width=device-width">
	<link rel="shortcut icon" type="image/x-icon" href="/favicon.ico" />
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="robots" content="index, follow" />
<link href="/bitrix/js/ui/bootstrap46/css/bootstrap.min.css?1611069473161409" type="text/css"  rel="stylesheet" />
<link href="/bitrix/cache/css/s1/bootstrap_v4/page_0d9e431b1581ddd7512d9f99d16b70d7/page_0d9e431b1581ddd7512d9f99d16b70d7_v1.css?17340786381232" type="text/css"  rel="stylesheet" />
<link href="/bitrix/cache/css/s1/bootstrap_v4/template_58cac2f3d705bca6ccbd3418c333acec/template_58cac2f3d705bca6ccbd3418c333acec_v1.css?16959004909220" type="text/css"  data-template-style="true" rel="stylesheet" />
<script type="text/javascript">if(!window.BX)window.BX={};if(!window.BX.message)window.BX.message=function(mess){if(typeof mess==='object'){for(let i in mess) {BX.message[i]=mess[i];} return true;}};</script>
<script type="text/javascript">(window.BX||top.BX).message({'JS_CORE_LOADING':'Загрузка...','JS_CORE_NO_DATA':'- Нет данных -','JS_CORE_WINDOW_CLOSE':'Закрыть','JS_CORE_WINDOW_EXPAND':'Развернуть','JS_CORE_WINDOW_NARROW':'Свернуть в окно','JS_CORE_WINDOW_SAVE':'Сохранить','JS_CORE_WINDOW_CANCEL':'Отменить','JS_CORE_WINDOW_CONTINUE':'Продолжить','JS_CORE_H':'ч','JS_CORE_M':'м','JS_CORE_S':'с','JSADM_AI_HIDE_EXTRA':'Скрыть лишние','JSADM_AI_ALL_NOTIF':'Показать все','JSADM_AUTH_REQ':'Требуется авторизация!','JS_CORE_WINDOW_AUTH':'Войти','JS_CORE_IMAGE_FULL':'Полный размер'});</script>

<script type="text/javascript" src="/bitrix/js/main/core/core.min.js?1661878784216224"></script>

<script>BX.setJSList(['/bitrix/js/main/core/core_ajax.js','/bitrix/js/main/core/core_promise.js','/bitrix/js/main/polyfill/promise/js/promise.js','/bitrix/js/main/loadext/loadext.js','/bitrix/js/main/loadext/extension.js','/bitrix/js/main/polyfill/promise/js/promise.js','/bitrix/js/main/polyfill/find/js/find.js','/bitrix/js/main/polyfill/includes/js/includes.js','/bitrix/js/main/polyfill/matches/js/matches.js','/bitrix/js/ui/polyfill/closest/js/closest.js','/bitrix/js/main/polyfill/fill/main.polyfill.fill.js','/bitrix/js/main/polyfill/find/js/find.js','/bitrix/js/main/polyfill/matches/js/matches.js','/bitrix/js/main/polyfill/core/dist/polyfill.bundle.js','/bitrix/js/main/core/core.js','/bitrix/js/main/polyfill/intersectionobserver/js/intersectionobserver.js','/bitrix/js/main/lazyload/dist/lazyload.bundle.js','/bitrix/js/main/polyfill/core/dist/polyfill.bundle.js','/bitrix/js/main/parambag/dist/parambag.bundle.js']);
BX.setCSSList(['/bitrix/js/main/lazyload/dist/lazyload.bundle.css','/bitrix/js/main/parambag/dist/parambag.bundle.css']);</script>
<script type="text/javascript">(window.BX||top.BX).message({'LANGUAGE_ID':'ru','FORMAT_DATE':'DD.MM.YYYY','FORMAT_DATETIME':'DD.MM.YYYY HH:MI:SS','COOKIE_PREFIX':'BITRIX_SM','SERVER_TZ_OFFSET':'21600','UTF_MODE':'Y','SITE_ID':'s1','SITE_DIR':'/','USER_ID':'','SERVER_TIME':'1774874641','USER_TZ_OFFSET':'0','USER_TZ_AUTO':'Y','bitrix_sessid':'5737b3271ca1c83426d01d9fcd855d03'});</script>


<script type="text/javascript"  src="/bitrix/cache/js/s1/bootstrap_v4/kernel_main/kernel_main_v1.js?1733894616175244"></script>
<script type="text/javascript" src="/bitrix/js/main/jquery/jquery-3.3.1.min.min.js?166187878486873"></script>
<script type="text/javascript" src="/bitrix/js/ui/bootstrap46/js/bootstrap.min.js?161106947363467"></script>
<script type="text/javascript">BX.setJSList(['/bitrix/js/main/core/core_fx.js','/bitrix/js/main/date/main.date.js','/bitrix/js/main/core/core_date.js','/bitrix/js/main/session.js','/bitrix/js/main/pageobject/pageobject.js','/bitrix/js/main/core/core_window.js','/bitrix/js/main/utils.js']);</script>
<script type="text/javascript">BX.setCSSList(['/bitrix/templates/bootstrap_v4/components/bitrix/main.map/.default/style.css','/bitrix/templates/bootstrap_v4/template_styles.css']);</script>


<script type="text/javascript">var _ba = _ba || []; _ba.push(["aid", "49a2f5ca5754a60413b9f30a82ef324a"]); _ba.push(["host", "raspisanie.medcoll.ru"]); (function() {var ba = document.createElement("script"); ba.type = "text/javascript"; ba.async = true;ba.src = (document.location.protocol == "https:" ? "https://" : "http://") + "bitrix.info/ba.js";var s = document.getElementsByTagName("script")[0];s.parentNode.insertBefore(ba, s);})();</script>


	<link rel="stylesheet" href="/bitrix/js/ui/fontawesome4/css/font-awesome.css">

</head>
<body class="bx-background-image bx-theme-blue" >
<div id="panel"></div>

<div class="bx-wrapper" id="bx_eshop_wrap">
	<header class="bx-header">
		<div class="bx-header-section container">
			<!--region bx-header-->
			<div class="row pt-0 pt-md-3 mb-3 align-items-center" style="position: relative;">
				<div class="d-block d-md-none bx-menu-button-mobile" data-role='bx-menu-button-mobile-position'></div>
				<div class="col-12 col-md-auto bx-header-logo">
					<a class="bx-logo-block d-none d-md-block" href="/">
						<img src="/include/logo.png" /><span>БПОУ Омской области "Медицинский колледж" </span>					</a>
					<a class="bx-logo-block d-block d-md-none text-center" href="/">
						<img src="/include/logo.jpg"  srcset="/include/logo.jpg" />					</a>
				</div>


				<div class="col bx-header-contact">
					<div class="d-flex align-items-center justify-content-between justify-content-md-center flex-column flex-sm-row flex-md-column flex-lg-row">
					 <div class="p-lg-3 p-1">
							<div class="bx-header-phone-block">
								<span class="bx-header-phone-number">
									<!-- <a class="nav-link font-weight-bold" href="tel:+78001009347" id="phone">+7(800)100-93-41</a>-->								</span>
							</div>
						</div> 
						<div class="p-lg-3 p-1">
							<div class="bx-header-worktime">
								<div class="bx-worktime-title"></div>
								<div class="bx-worktime-schedule">
																	</div>


							</div>
						</div> 
						
						<div class="p-lg-3 p-1">
							<div class="bx-header-worktime">								
								<div class="bx-worktime-schedule">
																	</div>


							</div>
						</div> 
					</div>
				</div>
			</div>
			<!--endregion-->

			<!--region menu-->
			<!--endregion-->

			<!--region search.title -->
			
						<!--endregion-->

			<!--endregion-->
<h1 id="pagetitle">Карта сайта</h1>
		</div>
	</header>

	<div class="workarea">
		<div class="container bx-content-section">
		<nav class="navbar navbar-expand-lg navbar-dark bg-primary mb-5">
  
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav">
      <li class="nav-item active">
        <a class="nav-link" href="/students/">Расписание студента</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="/teachers/">Расписание преподавателя</a>
      </li>
      
    </ul>
  </div>
</nav>
			<div class="row">

				<div class="bx-content col-12">

<!--end .container.bx-content-section-->
	</div></div>
</div></div><!--end .workarea-->

	 <footer class="bx-footer mt-5">
		<div class="bx-footer-section py-2 bg-secondary">
				<div class="container">
					<div class="row">
						<div class="col-sm-6 bx-up">
							<a href="javascript:void(0)" data-role="eshopUpButton" class="text-white"><i class="fa fa-caret-up"></i> Наверх</a>
						</div>
						<div class="col-sm-6 text-white text-right">
													</div>
					</div>
				</div>
			</div>
	</footer>

</div> <!-- //bx-wrapper -->


<script>
	BX.ready(function(){
		var upButton = document.querySelector('[data-role="eshopUpButton"]');
		BX.bind(upButton, "click", function(){
			var windowScroll = BX.GetWindowScrollPos();
			(new BX.easing({
				duration : 500,
				start : { scroll : windowScroll.scrollTop },
				finish : { scroll : 0 },
				transition : BX.easing.makeEaseOut(BX.easing.transitions.quart),
				step : function(state){
					window.scrollTo(0, state.scroll);
				},
				complete: function() {
				}
			})).animate();
		})
	});
</script>
</body>
</html>